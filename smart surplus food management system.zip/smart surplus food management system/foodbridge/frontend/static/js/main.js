document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.alert').forEach(function (alertBox) {
        setTimeout(function () {
            alertBox.style.opacity = '0';
            alertBox.style.transition = 'opacity 0.3s ease';
            setTimeout(function () { alertBox.remove(); }, 300);
        }, 3000);
    });
});
