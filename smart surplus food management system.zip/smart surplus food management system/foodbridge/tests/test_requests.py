from datetime import datetime, timedelta, timezone

from app import create_app
from backend.database import db
from backend.models import DonationRequest, FoodDonation, User


def test_receiver_can_request_and_donor_can_accept():
    app = create_app(test_config=True)
    with app.app_context():
        donor = User(username="donor2", email="donor2@example.com", role="donor", name="Donor Two")
        donor.set_password("secret123")
        receiver = User(username="receiver2", email="receiver2@example.com", role="receiver", name="Receiver Two")
        receiver.set_password("secret123")
        db.session.add_all([donor, receiver])
        db.session.commit()

        donation = FoodDonation(
            donor_id=donor.id,
            name="Soup Bowl",
            category="Vegetarian",
            quantity=10,
            quantity_remaining=10,
            quantity_unit="Meals",
            preparation_time=datetime.now(timezone.utc) - timedelta(hours=1),
            safe_deadline=datetime.now(timezone.utc) + timedelta(hours=6),
            pickup_location="City Center",
            status="Available",
        )
        db.session.add(donation)
        db.session.commit()

        with app.test_client() as client:
            client.post("/login", data={"email": "receiver2@example.com", "password": "secret123"}, follow_redirects=True)
            request_response = client.post(
                f"/receiver/request/{donation.id}",
                data={"quantity": "4"},
                follow_redirects=True,
            )
            assert request_response.status_code == 200
            assert DonationRequest.query.filter_by(donation_id=donation.id, receiver_id=receiver.id).count() == 1

            client.get("/logout")
            client.post("/login", data={"email": "donor2@example.com", "password": "secret123"}, follow_redirects=True)
            request_record = DonationRequest.query.filter_by(donation_id=donation.id).first()
            accept_response = client.post(f"/donor/accept_request/{request_record.id}", follow_redirects=True)
            assert accept_response.status_code == 200
            assert request_record.status == "Accepted"
