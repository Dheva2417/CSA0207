from backend.services.matching_service import calculate_match_score


def test_matching_score_is_normalized():
    score = calculate_match_score(1.0, 0.75, 1.0, 0.5)
    assert 0.0 <= score <= 1.0
    assert round(score, 3) == 0.875
