from datetime import datetime, timedelta, timezone

from app import create_app
from backend.database import db
from backend.models import FoodDonation, User


def test_donor_can_add_food_donation():
    app = create_app(test_config=True)
    with app.app_context():
        user = User(username="donor1", email="donor1@example.com", role="donor", name="Donor One")
        user.set_password("secret123")
        db.session.add(user)
        db.session.commit()

        with app.test_client() as client:
            client.post("/login", data={"email": "donor1@example.com", "password": "secret123"}, follow_redirects=True)
            response = client.post(
                "/donor/add_donation",
                data={
                    "name": "Rice Pack",
                    "category": "Vegetarian",
                    "quantity": "12",
                    "quantity_unit": "Meals",
                    "preparation_time": (datetime.now(timezone.utc) - timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M"),
                    "safe_deadline": (datetime.now(timezone.utc) + timedelta(hours=6)).strftime("%Y-%m-%dT%H:%M"),
                    "pickup_location": "Downtown Shelter",
                    "description": "Fresh rice packs",
                    "image_url": "",
                },
                follow_redirects=True,
            )
            assert response.status_code == 200
            assert FoodDonation.query.filter_by(name="Rice Pack").count() == 1
