from datetime import datetime, timedelta

from app import create_app
from backend.database import db
from backend.models import User


def test_register_and_login():
    app = create_app(test_config=True)
    with app.app_context():
        with app.test_client() as client:
            response = client.post(
                "/register",
                data={
                    "name": "Test User",
                    "username": "testuser",
                    "email": "testuser@example.com",
                    "phone": "1234567890",
                    "password": "secret123",
                    "role": "donor",
                },
                follow_redirects=True,
            )
            assert response.status_code == 200
            assert User.query.filter_by(email="testuser@example.com").count() == 1

            login_response = client.post(
                "/login",
                data={"email": "testuser@example.com", "password": "secret123"},
                follow_redirects=True,
            )
            assert login_response.status_code == 200
            assert b"Login successful" in login_response.data

            client.get("/logout")
