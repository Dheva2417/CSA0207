import os

from flask import Flask, abort, redirect, render_template, session, url_for

from backend.database import db
from backend.models import User
from backend.routes.admin_routes import admin_bp
from backend.routes.auth_routes import auth_bp
from backend.routes.donor_routes import donor_bp
from backend.routes.receiver_routes import receiver_bp
from config import Config, TestConfig


def create_app(test_config=None):
    app = Flask(
        __name__,
        template_folder=os.path.join(os.getcwd(), "frontend", "templates"),
        static_folder=os.path.join(os.getcwd(), "frontend", "static"),
    )
    app.config.from_object(TestConfig if test_config else Config)

    db.init_app(app)
    with app.app_context():
        db.create_all()
        ensure_admin_user()

    app.register_blueprint(auth_bp)
    app.register_blueprint(donor_bp)
    app.register_blueprint(receiver_bp)
    app.register_blueprint(admin_bp)

    @app.route("/dashboard")
    def dashboard_redirect():
        if "user_id" not in session:
            return redirect(url_for("auth_bp.login"))
        role = session.get("user_role")
        if role == "donor":
            return redirect(url_for("donor_bp.dashboard"))
        if role == "receiver":
            return redirect(url_for("receiver_bp.dashboard"))
        if role == "admin":
            return redirect(url_for("admin_bp.dashboard"))
        return redirect(url_for("auth_bp.login"))

    @app.route("/profile")
    def profile_page():
        if "user_id" not in session:
            return redirect(url_for("auth_bp.login"))
        user = db.session.get(User, session["user_id"])
        if user is None:
            abort(404)
        return render_template("profile.html", user=user)

    return app


def ensure_admin_user():
    if User.query.filter_by(email="admin@foodbridge.com").first() is None:
        admin = User(
            username="admin",
            email="admin@foodbridge.com",
            role="admin",
            name="FoodBridge Admin",
        )
        admin.set_password("admin123")
        db.session.add(admin)
        db.session.commit()


app = create_app()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
