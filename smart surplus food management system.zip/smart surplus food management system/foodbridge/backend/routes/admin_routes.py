from flask import Blueprint, render_template

from backend.auth import login_required, role_required
from backend.database import db
from backend.models import DonationRequest, FoodDonation, Notification, User
from backend.services.dashboard_service import (
    get_admin_dashboard_stats,
    get_category_distribution,
    get_donor_activity,
    get_monthly_trend,
    get_status_distribution,
    get_waste_prevention_monthly,
)

admin_bp = Blueprint("admin_bp", __name__, url_prefix="/admin")


@admin_bp.route("/dashboard")
@login_required
@role_required("admin")
def dashboard():
    stats = get_admin_dashboard_stats()
    recent_notifications = Notification.query.order_by(Notification.created_at.desc()).limit(8).all()
    donations = FoodDonation.query.order_by(FoodDonation.created_at.desc()).limit(10).all()
    users = User.query.order_by(User.created_at.desc()).all()

    return render_template(
        "admin_dashboard.html",
        stats=stats,
        trend=get_monthly_trend(),
        category_distribution=get_category_distribution(),
        status_distribution=get_status_distribution(),
        donor_activity=get_donor_activity(),
        waste_prevention=get_waste_prevention_monthly(),
        donations=donations,
        users=users,
        requests=DonationRequest.query.order_by(DonationRequest.created_at.desc()).all(),
        notifications=recent_notifications,
    )
