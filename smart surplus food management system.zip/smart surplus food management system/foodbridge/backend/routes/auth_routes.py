from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from backend.database import db
from backend.models import DonorProfile, FoodDonation, ReceiverProfile, User


auth_bp = Blueprint("auth_bp", __name__)


@auth_bp.route("/")
def index():
    return render_template("index.html")


@auth_bp.route("/donations")
def donations():
    search = request.args.get("search", "").strip()
    category = request.args.get("category")
    location = request.args.get("location", "").strip()
    available_only = request.args.get("available_only") == "1"

    query = FoodDonation.query
    if search:
        query = query.filter(FoodDonation.name.ilike(f"%{search}%"))
    if category:
        query = query.filter(FoodDonation.category == category)
    if location:
        query = query.filter(FoodDonation.pickup_location.ilike(f"%{location}%"))
    if available_only:
        query = query.filter(FoodDonation.status == "Available", FoodDonation.quantity_remaining > 0)

    return render_template("donations.html", donations=query.order_by(FoodDonation.created_at.desc()).all())


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "donor")

        if not all([name, username, email, password]):
            flash("Please fill in all required fields.", "danger")
            return render_template("register.html")

        if role not in {"donor", "receiver"}:
            flash("Invalid user role selected.", "danger")
            return render_template("register.html")

        if User.query.filter((User.email == email) | (User.username == username)).first():
            flash("A user with this email or username already exists.", "danger")
            return render_template("register.html")

        user = User(username=username, email=email, role=role, name=name, phone=phone)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        if role == "donor":
            db.session.add(
                DonorProfile(
                    user_id=user.id,
                    organization_name=request.form.get("organization_name") or name,
                    address=request.form.get("address") or "",
                    city=request.form.get("city") or "",
                    description=request.form.get("description") or "",
                )
            )
        else:
            db.session.add(
                ReceiverProfile(
                    user_id=user.id,
                    organization_name=request.form.get("organization_name") or name,
                    contact_person=name,
                    address=request.form.get("address") or "",
                    city=request.form.get("city") or "",
                    needs=request.form.get("needs") or "General food support",
                )
            )

        db.session.commit()
        flash("Registration successful. Please log in.", "success")
        return redirect(url_for("auth_bp.login"))

    return render_template("register.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()

        if not user or not user.check_password(password):
            flash("Invalid email or password.", "danger")
            return render_template("login.html")

        session["user_id"] = user.id
        session["user_role"] = user.role
        session["user_name"] = user.name
        flash("Login successful.", "success")
        return redirect(url_for("dashboard_redirect"))

    return render_template("login.html")


@auth_bp.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("auth_bp.index"))
