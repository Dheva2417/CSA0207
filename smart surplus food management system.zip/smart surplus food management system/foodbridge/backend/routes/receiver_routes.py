from datetime import datetime, timezone

from flask import Blueprint, abort, flash, redirect, render_template, request, session, url_for

from backend.auth import login_required, role_required
from backend.database import db
from backend.models import DonationRequest, FoodDonation, Notification, User, as_utc
from backend.services.matching_service import calculate_match_score

receiver_bp = Blueprint("receiver_bp", __name__, url_prefix="/receiver")


@receiver_bp.route("/dashboard")
@login_required
@role_required("receiver")
def dashboard():
    now = datetime.now(timezone.utc)
    donations = FoodDonation.query.filter(
        FoodDonation.status == "Available",
        FoodDonation.quantity_remaining > 0,
        FoodDonation.safe_deadline > now,
    ).order_by(FoodDonation.safe_deadline.asc()).all()

    receiver = db.session.get(User, session["user_id"])
    recommended = []
    preferred_category = "Vegetarian"
    preferred_location = receiver.name if receiver else ""

    for donation in donations:
        donation_deadline = as_utc(donation.safe_deadline)
        if donation.quantity_remaining <= 0 or donation_deadline < now:
            continue
        category_match = 1.0 if donation.category.lower() == preferred_category.lower() else 0.5
        quantity_match = min(1.0, (donation.quantity_remaining / max(donation.quantity, 1)) if donation.quantity else 1.0)
        location_match = 1.0 if preferred_location and donation.pickup_location.lower() == preferred_location.lower() else 0.7
        urgency_score = max(0.0, min(1.0, 1 - ((donation_deadline - now).total_seconds() / 86400)))
        score = calculate_match_score(category_match, quantity_match, location_match, urgency_score)
        recommended.append({"donation": donation, "score": round(score, 3)})

    recommended.sort(key=lambda x: x["score"], reverse=True)
    notifications = Notification.query.filter_by(user_id=session["user_id"]).order_by(Notification.created_at.desc()).all()

    return render_template(
        "receiver_dashboard.html",
        donations=donations,
        recommendations=recommended[:5],
        notifications=notifications,
        user_name=session.get("user_name"),
    )


@receiver_bp.route("/request/<donation_id>", methods=["POST"])
@login_required
@role_required("receiver")
def request_donation(donation_id):
    donation = db.session.get(FoodDonation, donation_id)
    if donation is None:
        abort(404)
    receiver_id = session["user_id"]
    requested_quantity = float(request.form.get("quantity", 0))

    if donation.status != "Available" or donation.quantity_remaining <= 0:
        flash("This donation is no longer available.", "danger")
        return redirect(url_for("receiver_bp.dashboard"))
    if requested_quantity <= 0:
        flash("Requested quantity must be greater than zero.", "danger")
        return redirect(url_for("receiver_bp.dashboard"))
    if requested_quantity > donation.quantity_remaining:
        flash("You cannot request more than the available quantity.", "danger")
        return redirect(url_for("receiver_bp.dashboard"))
    if DonationRequest.query.filter_by(donation_id=donation_id, receiver_id=receiver_id, status="Request Pending").first():
        flash("You already submitted a pending request for this donation.", "warning")
        return redirect(url_for("receiver_bp.dashboard"))

    request_record = DonationRequest(
        donation_id=donation.id,
        receiver_id=receiver_id,
        requested_quantity=requested_quantity,
        status="Request Pending",
    )
    db.session.add(request_record)
    db.session.add(
        Notification(
            user_id=donation.donor_id,
            message=f"A receiver requested {requested_quantity} {donation.quantity_unit} of {donation.name}.",
            notification_type="info",
        )
    )
    db.session.commit()
    flash("Donation request submitted successfully.", "success")
    return redirect(url_for("receiver_bp.dashboard"))
