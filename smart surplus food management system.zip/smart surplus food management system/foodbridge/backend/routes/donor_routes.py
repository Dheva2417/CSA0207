from datetime import datetime, timezone

from flask import Blueprint, abort, flash, redirect, render_template, request, session, url_for

from backend.auth import login_required, role_required
from backend.database import db
from backend.models import DonationRequest, DonationTransaction, FoodDonation, Notification


donor_bp = Blueprint("donor_bp", __name__, url_prefix="/donor")


def parse_utc_datetime(value):
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


@donor_bp.route("/dashboard")
@login_required
@role_required("donor")
def dashboard():
    donor_id = session["user_id"]
    donations = FoodDonation.query.filter_by(donor_id=donor_id).order_by(FoodDonation.created_at.desc()).all()
    requests = DonationRequest.query.join(FoodDonation, DonationRequest.donation_id == FoodDonation.id).filter(FoodDonation.donor_id == donor_id).order_by(DonationRequest.created_at.desc()).all()

    total_quantity = sum(float(d.quantity) for d in donations)
    active = sum(1 for d in donations if d.status in {"Available", "Request Pending", "Accepted", "Ready for Pickup"})
    pending_requests = sum(1 for r in requests if r.status == "Request Pending")

    return render_template(
        "donor_dashboard.html",
        donations=donations,
        requests=requests,
        total_quantity=total_quantity,
        active=active,
        pending_requests=pending_requests,
        user_name=session.get("user_name"),
    )


@donor_bp.route("/add_donation", methods=["POST"])
@login_required
@role_required("donor")
def add_donation():
    donor_id = session["user_id"]
    required_fields = ["name", "category", "quantity", "quantity_unit", "preparation_time", "safe_deadline", "pickup_location"]
    if not all(request.form.get(field) for field in required_fields):
        flash("Please fill in all required donation fields.", "danger")
        return redirect(url_for("donor_bp.dashboard"))

    try:
        quantity = float(request.form.get("quantity"))
    except ValueError:
        flash("Quantity must be a valid number.", "danger")
        return redirect(url_for("donor_bp.dashboard"))

    if quantity <= 0:
        flash("Donation quantity must be greater than zero.", "danger")
        return redirect(url_for("donor_bp.dashboard"))

    try:
        prep = parse_utc_datetime(request.form.get("preparation_time"))
        deadline = parse_utc_datetime(request.form.get("safe_deadline"))
    except ValueError:
        flash("Dates must be valid ISO timestamps.", "danger")
        return redirect(url_for("donor_bp.dashboard"))

    donation = FoodDonation(
        donor_id=donor_id,
        name=request.form.get("name").strip(),
        category=request.form.get("category"),
        quantity=quantity,
        quantity_remaining=quantity,
        quantity_unit=request.form.get("quantity_unit"),
        preparation_time=prep,
        safe_deadline=deadline,
        pickup_location=request.form.get("pickup_location").strip(),
        description=request.form.get("description", "").strip(),
        image_url=request.form.get("image_url") or "",
        status="Expired" if datetime.now(timezone.utc) > deadline else "Available",
    )

    db.session.add(donation)
    db.session.commit()
    flash("Donation added successfully.", "success")
    return redirect(url_for("donor_bp.dashboard"))


@donor_bp.route("/delete_donation/<donation_id>", methods=["POST"])
@login_required
@role_required("donor")
def delete_donation(donation_id):
    donation = FoodDonation.query.filter_by(id=donation_id, donor_id=session["user_id"]).first_or_404()
    donation.status = "Cancelled"
    db.session.commit()
    flash("Donation cancelled.", "info")
    return redirect(url_for("donor_bp.dashboard"))


@donor_bp.route("/accept_request/<request_id>", methods=["POST"])
@login_required
@role_required("donor")
def accept_request(request_id):
    request_record = db.session.get(DonationRequest, request_id)
    if request_record is None:
        abort(404)
    donation = FoodDonation.query.filter_by(id=request_record.donation_id, donor_id=session["user_id"]).first_or_404()

    if request_record.status != "Request Pending":
        flash("This request is no longer pending.", "warning")
        return redirect(url_for("donor_bp.dashboard"))

    accepted_quantity = min(float(request_record.requested_quantity), float(donation.quantity_remaining))
    if accepted_quantity <= 0:
        flash("No available quantity remains.", "danger")
        return redirect(url_for("donor_bp.dashboard"))

    donation.quantity_remaining = max(0.0, donation.quantity_remaining - accepted_quantity)
    donation.status = "Ready for Pickup" if donation.quantity_remaining > 0 else "Completed"
    request_record.status = "Accepted"
    request_record.accepted_quantity = accepted_quantity
    request_record.reviewed_at = datetime.now(timezone.utc)

    db.session.add(
        DonationTransaction(
            donation_id=donation.id,
            request_id=request_record.id,
            donor_id=donation.donor_id,
            receiver_id=request_record.receiver_id,
            quantity=accepted_quantity,
            action="Accepted",
        )
    )
    db.session.add(
        Notification(
            user_id=request_record.receiver_id,
            message=f"Your request for {donation.name} was accepted.",
            notification_type="success",
        )
    )
    db.session.commit()
    flash("Request accepted and marked for pickup.", "success")
    return redirect(url_for("donor_bp.dashboard"))


@donor_bp.route("/reject_request/<request_id>", methods=["POST"])
@login_required
@role_required("donor")
def reject_request(request_id):
    request_record = db.session.get(DonationRequest, request_id)
    if request_record is None:
        abort(404)
    donation = FoodDonation.query.filter_by(id=request_record.donation_id, donor_id=session["user_id"]).first_or_404()

    if request_record.status != "Request Pending":
        flash("This request has already been processed.", "warning")
        return redirect(url_for("donor_bp.dashboard"))

    request_record.status = "Rejected"
    request_record.reviewed_at = datetime.now(timezone.utc)
    donation.status = "Available" if donation.quantity_remaining > 0 else "Completed"
    db.session.add(
        Notification(
            user_id=request_record.receiver_id,
            message=f"Your request for {donation.name} was rejected.",
            notification_type="warning",
        )
    )
    db.session.commit()
    flash("Request rejected.", "info")
    return redirect(url_for("donor_bp.dashboard"))
