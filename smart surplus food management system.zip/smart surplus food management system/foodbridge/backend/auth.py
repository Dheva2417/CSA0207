from functools import wraps
from flask import redirect, render_template, request, session, url_for


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("auth_bp.login"))
        return f(*args, **kwargs)
    return decorated_function


def role_required(*allowed_roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            user_role = session.get("user_role")
            if user_role not in allowed_roles:
                return render_template("index.html", error="Access denied for your role."), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator
