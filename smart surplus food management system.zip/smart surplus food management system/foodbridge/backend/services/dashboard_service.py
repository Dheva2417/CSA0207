from collections import defaultdict

from backend.database import db
from backend.models import DonationRequest, FoodDonation, User


def get_admin_dashboard_stats():
    donors = User.query.filter_by(role="donor").count()
    receivers = User.query.filter_by(role="receiver").count()
    total_donations = FoodDonation.query.count()
    completed_donations = FoodDonation.query.filter_by(status="Completed").count()
    total_quantity = db.session.query(db.func.coalesce(db.func.sum(FoodDonation.quantity), 0)).scalar() or 0
    distributed_quantity = db.session.query(db.func.coalesce(db.func.sum(FoodDonation.quantity), 0)).filter(FoodDonation.status == "Completed").scalar() or 0
    pending_requests = DonationRequest.query.filter_by(status="Request Pending").count()
    estimated_waste_prevented = round(distributed_quantity * 0.75, 2)

    return {
        "registered_donors": donors,
        "registered_receivers": receivers,
        "total_food_donations": total_donations,
        "completed_donations": completed_donations,
        "total_food_quantity": float(total_quantity),
        "pending_requests": pending_requests,
        "estimated_waste_prevented": float(estimated_waste_prevented),
        "distributed_quantity": float(distributed_quantity),
    }


def get_monthly_trend():
    rows = db.session.query(
        db.func.strftime("%Y-%m", FoodDonation.created_at),
        db.func.count(FoodDonation.id),
    ).group_by(db.func.strftime("%Y-%m", FoodDonation.created_at)).all()
    labels = []
    values = []
    for month, count in rows:
        labels.append(month)
        values.append(count)
    return {"labels": labels, "values": values}


def get_category_distribution():
    rows = db.session.query(FoodDonation.category, db.func.count(FoodDonation.id)).group_by(FoodDonation.category).all()
    labels = [category for category, _ in rows]
    values = [count for _, count in rows]
    return {"labels": labels, "values": values}


def get_status_distribution():
    rows = db.session.query(FoodDonation.status, db.func.count(FoodDonation.id)).group_by(FoodDonation.status).all()
    labels = [status for status, _ in rows]
    values = [count for _, count in rows]
    return {"labels": labels, "values": values}


def get_donor_activity():
    rows = db.session.query(User.name, db.func.count(FoodDonation.id)).outerjoin(FoodDonation, FoodDonation.donor_id == User.id).filter(User.role == "donor").group_by(User.id).all()
    labels = [name for name, _ in rows]
    values = [count for _, count in rows]
    return {"labels": labels, "values": values}


def get_waste_prevention_monthly():
    rows = db.session.query(
        db.func.strftime("%Y-%m", FoodDonation.updated_at),
        db.func.sum(FoodDonation.quantity - FoodDonation.quantity_remaining),
    ).filter(FoodDonation.status == "Completed").group_by(db.func.strftime("%Y-%m", FoodDonation.updated_at)).all()
    labels = []
    values = []
    for month, total in rows:
        labels.append(month)
        values.append(float(total or 0))
    return {"labels": labels, "values": values}
