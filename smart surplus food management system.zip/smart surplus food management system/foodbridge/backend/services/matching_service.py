import ctypes
import os
import shutil
import subprocess
from pathlib import Path


LIB_PATH = Path(__file__).resolve().parents[2] / "c_engine"


def _ensure_library_built():
    lib_name = "libfood_matching.so" if os.name != "nt" else "food_matching.dll"
    target = LIB_PATH / lib_name
    if target.exists():
        return str(target)

    compiler = shutil.which("gcc") or shutil.which("clang") or shutil.which("cc")
    if compiler is None:
        raise RuntimeError("No C compiler found. Install GCC or clang to build the matching library.")

    source = LIB_PATH / "food_matching.c"
    if not source.exists():
        raise FileNotFoundError("C engine source files are missing. Compile them from c_engine/.")

    cmd = [compiler, "-shared", "-O2"]
    if os.name == "nt":
        cmd += ["-o", str(target), str(source)]
    else:
        cmd += ["-fPIC", "-o", str(target), str(source)]

    subprocess.run(cmd, cwd=str(LIB_PATH), check=True)
    return str(target)


def calculate_match_score(category_match, quantity_match, location_match, urgency_score):
    try:
        lib_path = _ensure_library_built()
        lib = ctypes.CDLL(lib_path)
        lib.calculate_match_score.argtypes = [ctypes.c_double, ctypes.c_double, ctypes.c_double, ctypes.c_double]
        lib.calculate_match_score.restype = ctypes.c_double
        return lib.calculate_match_score(
            float(category_match),
            float(quantity_match),
            float(location_match),
            float(urgency_score),
        )
    except Exception:
        total = (40.0 * float(category_match) + 30.0 * float(quantity_match) + 20.0 * float(location_match) + 10.0 * float(urgency_score)) / 100.0
        return max(0.0, min(1.0, total))
