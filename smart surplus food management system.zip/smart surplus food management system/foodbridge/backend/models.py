from datetime import datetime, timezone
from uuid import uuid4

from werkzeug.security import check_password_hash, generate_password_hash

from backend.database import db


def as_utc(value):
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="donor")
    name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(30), nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    donations = db.relationship("FoodDonation", backref="donor_user", lazy="dynamic")
    requests = db.relationship("DonationRequest", foreign_keys="DonationRequest.receiver_id", backref="receiver_user", lazy="dynamic")
    notifications = db.relationship("Notification", backref="user", lazy="dynamic")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class DonorProfile(db.Model):
    __tablename__ = "donor_profiles"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)
    organization_name = db.Column(db.String(150), nullable=True)
    address = db.Column(db.String(250), nullable=True)
    city = db.Column(db.String(100), nullable=True)
    description = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)


class ReceiverProfile(db.Model):
    __tablename__ = "receiver_profiles"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)
    organization_name = db.Column(db.String(150), nullable=True)
    contact_person = db.Column(db.String(120), nullable=True)
    address = db.Column(db.String(250), nullable=True)
    city = db.Column(db.String(100), nullable=True)
    needs = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)


class FoodDonation(db.Model):
    __tablename__ = "food_donations"

    id = db.Column(db.String(40), primary_key=True, default=lambda: f"FD-{uuid4().hex[:8].upper()}")
    donor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    name = db.Column(db.String(150), nullable=False)
    category = db.Column(db.String(30), nullable=False)
    quantity = db.Column(db.Float, nullable=False, default=0)
    quantity_remaining = db.Column(db.Float, nullable=False, default=0)
    quantity_unit = db.Column(db.String(30), nullable=False)
    preparation_time = db.Column(db.DateTime, nullable=False)
    safe_deadline = db.Column(db.DateTime, nullable=False)
    pickup_location = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    image_url = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(25), nullable=False, default="Available")
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)
    requests = db.relationship("DonationRequest", foreign_keys="DonationRequest.donation_id", backref="donation", lazy="dynamic")

    @property
    def is_expired(self):
        return datetime.now(timezone.utc) > as_utc(self.safe_deadline)


class DonationRequest(db.Model):
    __tablename__ = "donation_requests"

    id = db.Column(db.String(40), primary_key=True, default=lambda: f"DR-{uuid4().hex[:8].upper()}")
    donation_id = db.Column(db.String(40), db.ForeignKey("food_donations.id"), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    requested_quantity = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(30), nullable=False, default="Request Pending")
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    reviewed_at = db.Column(db.DateTime, nullable=True)
    accepted_quantity = db.Column(db.Float, nullable=True)


class DonationTransaction(db.Model):
    __tablename__ = "donation_transactions"

    id = db.Column(db.String(40), primary_key=True, default=lambda: f"TX-{uuid4().hex[:8].upper()}")
    donation_id = db.Column(db.String(40), db.ForeignKey("food_donations.id"), nullable=False)
    request_id = db.Column(db.String(40), db.ForeignKey("donation_requests.id"), nullable=True)
    donor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    quantity = db.Column(db.Float, nullable=False, default=0)
    action = db.Column(db.String(50), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)


class Notification(db.Model):
    __tablename__ = "notifications"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    message = db.Column(db.String(255), nullable=False)
    notification_type = db.Column(db.String(30), nullable=False, default="info")
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
