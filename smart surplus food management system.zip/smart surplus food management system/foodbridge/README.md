# FoodBridge

FoodBridge is a full-stack Flask application that connects surplus food donors with receivers while using a C-based matching engine for prioritization and quantity-aware scoring.

## Features

- Donor, receiver, and admin roles
- SQLite persistence with SQLAlchemy
- Real donation lifecycle management
- C-based weighted food matching using ctypes
- Responsive Bootstrap 5 frontend
- Automated tests for auth, donations, requests, and matching

## Project structure

```text
foodbridge/
├── app.py
├── config.py
├── requirements.txt
├── README.md
├── backend/
│   ├── __init__.py
│   ├── auth.py
│   ├── database.py
│   ├── models.py
│   └── routes/
│       ├── admin_routes.py
│       ├── auth_routes.py
│       ├── donor_routes.py
│       ├── receiver_routes.py
├── c_engine/
│   ├── food_matching.c
│   ├── food_matching.h
│   ├── Makefile
│   └── build instructions
├── frontend/
│   ├── static/
│   │   ├── css/style.css
│   │   └── js/main.js
│   └── templates/
│       ├── admin_dashboard.html
│       ├── donor_dashboard.html
│       ├── index.html
│       ├── login.html
│       ├── profile.html
│       ├── receiver_dashboard.html
│       ├── register.html
│       └── donations.html
├── instance/
│   └── foodbridge.db
├── tests/
│   ├── test_auth.py
│   ├── test_donations.py
│   ├── test_matching.py
│   └── test_requests.py
└── .venv/
```

## Setup

### Windows

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
gcc -shared -O2 -o c_engine\food_matching.dll c_engine\food_matching.c
python app.py
```

### Linux/macOS

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
gcc -shared -fPIC -O2 -o c_engine/libfood_matching.so c_engine/food_matching.c
python app.py
```

## Verify the app

```bash
python -m pytest -q
```

## Default admin account

The application creates an admin user automatically if none exists:

- Email: admin@foodbridge.com
- Password: admin123

## Run tests

`pytest`

## Access locally

Open http://localhost:5000 in the browser.
