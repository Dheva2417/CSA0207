#ifndef FOOD_MATCHING_H
#define FOOD_MATCHING_H

double calculate_match_score(double category_match, double quantity_match, double location_match, double urgency_score);

#endif
