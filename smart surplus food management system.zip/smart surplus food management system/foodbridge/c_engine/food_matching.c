#include "food_matching.h"

double calculate_match_score(double category_match, double quantity_match, double location_match, double urgency_score) {
    double score = (40.0 * category_match + 30.0 * quantity_match + 20.0 * location_match + 10.0 * urgency_score) / 100.0;
    if (score < 0.0) {
        return 0.0;
    }
    if (score > 1.0) {
        return 1.0;
    }
    return score;
}
